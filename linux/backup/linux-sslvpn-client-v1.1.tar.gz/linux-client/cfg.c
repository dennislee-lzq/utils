/*
 * Copyright(C) 2016 Ruijie Network. All rights reserved.
 */
/*
 * IPTunnelCfg.c
 * Original Author:  lizhiqiang@ruijie.com.cn, 2016-7-09
 *
 * �ļ�����˵��
 *
 * History
 */

#include <stdio.h>
#include <stdint.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <linux/if_tun.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <netinet/in.h>

#include "iptunnel.h"
#include "debug.h"
#include "cfg.h"

#define BYTES_OF_LEN            1
#define BYTES_OF_TYPE           1
#define BYTES_OF_TL             (BYTES_OF_TYPE + BYTES_OF_LEN)
#define min(x, y)               ((x) < (y) ? (x) : (y))

static int iptun_parse_virt_ip(uint8_t *value, int len);
static int iptun_create_intf(char *iface);
static int iptun_set_ipaddr(char *iface, IPADDRTYPE ip, IPADDRTYPE mask);
static int iptun_parse_dns(uint8_t *value, int len);
static int iptun_parse_route(uint8_t *value, int len);

/**
 * tlv_decode_from_buf - ����TLV�ṹ���
 * @tlv_buf:Ҫ������tlv���
 * @type:������������(����)
 * @length:������ݳ���(����)
 * @value_buf:����������(����)
 * @buf_len:����valueֵ��buf�ĳ���
 * 
 * ������ʹ��ʱҪע�������ֽ���������������
 * ���һ��������ڶ���TLVֵ��������һ��TLVֵʱ��buf�׵�ַҪ����ǰ�ƽ�length + BYTES_OF_TL���ֽ�
 *
 * �����ɹ�����SSLVPN_IPTUN_OK,�����ʾ��value_buf��������,valueδ������ɷ��ز����������С
 */
int8_t tlv_decode_from_buf(const void *tlv_buf, uint8_t *type, uint8_t *length,
		uint8_t *value_buf, uint8_t buf_len) {
	if (tlv_buf == NULL || type == NULL || length == NULL || value_buf == NULL) {
		return SSLVPN_IPTUN_ERROR;
	}

	memcpy(type, tlv_buf, BYTES_OF_TYPE);
	memcpy(length, ((uint8_t *) tlv_buf) + BYTES_OF_TYPE, BYTES_OF_LEN);
	memcpy(value_buf, ((uint8_t *) tlv_buf) + BYTES_OF_TL,
			min(*length, buf_len));

	if (buf_len >= *length) {
		return SSLVPN_IPTUN_OK;
	} else {
		return (*length - buf_len);
	}
}

#define IPV4_LOOKBACK_MASK      0XFF000000
#define IPV4_LOOKBACK_NETWORK   0X7F000000
#define IPV4_BROADCAST          (-1U)
#define IP_MCAST_SUBNET_MASK    ((in_addr_t)240<<24)  /* 1111 0000 */
#define IP_MCAST_NETWORK        ((in_addr_t)224<<24)  /* 1110 0000 */

#define CMD_LINE_LEN    255

iptun_cfg_t g_cfg;

void iptun_cfg_init(void) {
	memset(&g_cfg, 0, sizeof(iptun_cfg_t));
}

static inline void iptun_itoa(IPADDRTYPE ip, char *ipstr) {
	u_char *p;

	if (ipstr == NULL) {
		return;
	}

	p = (u_char *) &ip;
	if (htonl(ip) == ip) { /* big-endian */
		sprintf(ipstr, "%u.%u.%u.%u", p[0], p[1], p[2], p[3]);
	} else { /* little-endian */
		sprintf(ipstr, "%u.%u.%u.%u", p[3], p[2], p[1], p[0]);
	}
}

static inline bool iptun_ipv4_check(IPADDRTYPE ip) {
	if ((ip & htonl(IPV4_LOOKBACK_MASK)) == htonl(IPV4_LOOKBACK_NETWORK)) {
		return false;
	}
	if ((ip & htonl(IP_MCAST_SUBNET_MASK)) == htonl(IP_MCAST_NETWORK)) {
		return false;
	}
	if (ip == IPV4_BROADCAST) {
		return false;
	}

	return true;
}

static int iptun_parse_virt_ip(uint8_t *value, int len) {
	IPADDRTYPE ip, mask;
	bool ret;
	char iface[IFNAMSIZ];
	int fd;

	if (len != 2 * sizeof(IPADDRTYPE)) {
		print_error("ip value invalid\n");
		return SSLVPN_IPTUN_ERROR;
	}

	/* ����������IP��ַ */
	memcpy(&ip, value, sizeof(IPADDRTYPE));
	memcpy(&mask, value + sizeof(IPADDRTYPE), sizeof(IPADDRTYPE));

	ip = ntohl(ip);
	mask = ntohl(mask);
	if (ip == 0 || mask == 0 || ((~mask & (~mask + 1)) != 0)
			|| !iptun_ipv4_check(htonl(ip))) {
		print_error("Illegal virtual IP or mask %x %x.\n", ip, mask);
		return SSLVPN_IPTUN_ERROR;
	}

	fd = iptun_create_intf(iface);
	if (fd < 0) {
		print_error("create interface fail\n");
		return SSLVPN_IPTUN_ERROR;
	}
	ret = iptun_set_ipaddr(iface, ip, mask);
	if (ret != 0) {
		print_error("set ip addr to interface fail\n");
		return SSLVPN_IPTUN_ERROR;
	}
	g_cfg.vip = ip;
	g_cfg.vgw=(ip & mask) + 1;
	g_running_ctx.vpn_intf_fd = fd;
	/* XXX: set max fd */

	return SSLVPN_IPTUN_OK;
}

/* create tap/tun interface(in fact, always tun), and get the name of interface */
static int iptun_create_intf(char *iface) {
	struct ifreq ifr;
	int fd, err;

	if ((fd = open("/dev/net/tun", O_RDWR)) < 0) {
		print_error("fail to open tun\n");
		return fd;
	}
	memset(&ifr, 0, sizeof(ifr));
	ifr.ifr_flags = IFF_TUN | IFF_NO_PI;
	/*
	 if (*iface != '\0') {
	 strncpy(ifr.ifr_name, iface, IFNAMSIZ);
	 }
	 */
	err = ioctl(fd, TUNSETIFF, (void *) &ifr);
	if (err < 0) {
		close(fd);
		print_error("fail to ioctl\n");
		return err;
	}
	/* set_nonblock (fd); */
	strncpy(iface, ifr.ifr_name, IFNAMSIZ);

	return fd;
}

static int iptun_set_ipaddr(char *iface, IPADDRTYPE ip, IPADDRTYPE mask) {
	char ipstr[SSLVPN_IP_ADDR_LEN];
	char maskstr[SSLVPN_IP_ADDR_LEN];
	char cmd[CMD_LINE_LEN];

	iptun_itoa(ip, ipstr);
	iptun_itoa(mask, maskstr);

	snprintf(cmd, CMD_LINE_LEN, "ifconfig %s %s netmask %s up", iface, ipstr,
			maskstr);
	iptun_print("%s\n", cmd);
	return system(cmd);
}

static int iptun_parse_dns(uint8_t *value, int len) {

}

static int iptun_parse_route(uint8_t *value, int len) {
	IPADDRTYPE net, mask;
	char gwstr[SSLVPN_IP_ADDR_LEN];
	char netstr[SSLVPN_IP_ADDR_LEN];
	char maskstr[SSLVPN_IP_ADDR_LEN];
	char cmd[CMD_LINE_LEN];

#if 0
	if (len != 2 * sizeof(IPADDRTYPE)) { /* XXX: include acl info */
		print_error("route value invalid\n");
		return SSLVPN_IPTUN_ERROR;
	}
#endif

	/* ����������IP��ַ */
	memcpy(&net, value, sizeof(IPADDRTYPE));
	memcpy(&mask, value + sizeof(IPADDRTYPE), sizeof(IPADDRTYPE));

	net = ntohl(net);
	mask = ntohl(mask);
	iptun_itoa(g_cfg.vgw, gwstr);
	iptun_itoa(net, netstr);
	iptun_itoa(mask, maskstr);

	snprintf(cmd, CMD_LINE_LEN, "route add -net  %s netmask %s gw %s", netstr,
			maskstr, gwstr);
	iptun_print("%s\n", cmd);
	(void) system(cmd);

	return SSLVPN_IPTUN_OK;
}

/* Native����ͨ��JNI�ص��������ý��� */
int iptunConfigParse(uint8_t *ctrl_msg, int msg_len) {
	uint8_t type;
	uint8_t length;
	uint8_t value[UCHAR_MAX];
	int8_t tlv_dec_ret;
	int tlv_tot_len;
	int len;
	int ret;

	ret = 0;

	len = msg_len;
	while (len > 0) {
		/* �ӿ�����Ϣ����ȡ��TLV�ֶ� */
		tlv_dec_ret = tlv_decode_from_buf(ctrl_msg, &type, &length, value,
				sizeof(value));
		tlv_tot_len = BYTES_OF_TL + length; /* T + L + V ���ֽ����� */
		if (tlv_dec_ret != SSLVPN_IPTUN_OK) {
			/* ��Ϊvalue�Ŀռ䲻��������TLV��������һ��TLV�� */
			print_error("Error, T:%d L:%d buf_size:%lu only!\n", type, length,
					sizeof(value));
			ctrl_msg += tlv_tot_len;
			len -= tlv_tot_len;
			continue;
		}

		if (len < tlv_tot_len) {
			/* Ҫ������TLV�ڻ����в����� */
			print_error("Error, bad TLV, tlv total len is %d buf_len is %d\n",
					tlv_tot_len, len);
			ctrl_msg += tlv_tot_len;
			len -= tlv_tot_len;
			continue;
		}

		iptun_print("Type: %x Length: %d RemainLength: %d\n", type, length,
				len);

		/* �������Ʊ��� */
		switch (type) {
		case IPTUN_TLV_TYPE_VIRT_IP:
			/* ��������IP */
			if (iptun_parse_virt_ip(value, length) != SSLVPN_IPTUN_OK) {
				print_error("iptun parse virt ip fail\n");
				return SSLVPN_IPTUN_ERROR;
			}
			break;
		case IPTUN_TLV_TYPE_NAME_SER:
			/* ����DNS */
			if (iptun_parse_dns(value, length) != SSLVPN_IPTUN_OK) {
				/* ignore */
			}
			break;
		case IPTUN_TLV_TYPE_WINS_ADDR:
			/* ignore */
			break;
		case IPTUN_TLV_TYPE_ACC_MODE:
			/* ignore */
			break;
		case IPTUN_TLV_TYPE_RT_ADD:
			/* ����һ��������ʵ���Դ */
			if (iptun_parse_route(value, length) != SSLVPN_IPTUN_OK) {
				print_error("iptun parse route  fail\n");
				return SSLVPN_IPTUN_ERROR;
			}
			break;
		case IPTUN_TLV_TYPE_CFG_OVER:
			/* ���ý���*/
			g_running_ctx.state = IPTUN_STATE_FORWORD;
			print_info("connect server successfully\n");
			ret = 1;
			break;
		default:
			/* �������Ϣ�Թ� */
			print_error("bad ctrl type(%x) l: %d\n", type, length);
			break;
		} /* END switch */

		ctrl_msg += tlv_tot_len;
		len -= tlv_tot_len;
	}

	return ret;
}

