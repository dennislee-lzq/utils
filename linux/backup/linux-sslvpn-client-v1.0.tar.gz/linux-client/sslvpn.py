#!/usr/bin/python

import time
import urllib
import httplib
import re
import base64
import StringIO
import string
import socket
import os

use_rjvpn = 1
do_hardid = 1
username="lizhiqiang"
sessionid="66654c466b36bb042940e67d978176e5"
hardid="906D0FD6CD25AAF64384C773470A31DF"
headers = {}


if (use_rjvpn):
	server = "rjvpn.ruijie.com.cn"
	port = 443
	password="baishile"
else:
	server = "fzyfvpn.ruijie.com.cn"
	port = 1443
	password="lizq123"
	
def test1():
	print "**********Just for test************"
	global headers
	conn = httplib.HTTPSConnection(server, port)
	conn.request("GET", "/sslvpn/action/getTitle?a=3","", headers)              
	res = conn.getresponse();
	print res.status, res.reason
	print res.read()

def test2():
	conn = httplib.HTTPSConnection("rjvpn.ruijie.com.cn")
	conn.request("GET", "/","", {})              
	res = conn.getresponse();
	print "verion:", res.version
	print "status:", res.status
	print "resion:", res.reason
	print "all date:", res.read()
	print "msg:", res.msg
	print "headers:", res.getheaders()
	print "set cookie header:", res.getheader("set-cookie")
	sc = res.getheader("set-cookie");
	print sc.split(',')
	#rjsslvpnSID=fafd1815faaac7c90435ccb34229cb89; path=/, rjsslvpnCF=184; path=/, rjsslvpnVER=16777216; path=/
	m = re.match(r"rjsslvpnSID=(.*);.*rjsslvpnCF=(.*);.*rjsslvpnVER=(.*);", sc)
	print "group",  m.group(1), m.group(2), m.group(3)
	
def login():
	print "**********try to login************"
	global headers
	postdata={'realm':'user', 'verifycode':'','terminal':'web'}	
	postdata['username'] = username
	postdata['password'] = password

	#params=urllib.urlencode({'realm':'user','username':'lizhiqiang','password':'lizq123','verifycode':'','terminal':'web'})
	params=urllib.urlencode(postdata)
	#print params
	
	conn = httplib.HTTPSConnection(server, port)
	conn.request("POST", "/sslvpn/action/login", params, headers)              
	res = conn.getresponse();
	print res.status, res.reason, res.getheader("Location")
	print res.read()
	
def check_hardid():
	print "*********check hardid************"
	global headers
	postdata={}	
	postdata['hardid'] = hardid
	
	conn = httplib.HTTPSConnection(server, port)
	params=urllib.urlencode(postdata)
	print params
	conn.request("POST", "/sslvpn/action/checkHardID", params, headers)              
	res = conn.getresponse();
	print res.status, res.reason
	print res.read()

def keepalive():
	print "**********keepalive************"
	global headers
	conn = httplib.HTTPSConnection(server, port)
	conn.request("GET", "/sslvpn/action/requestTimeout?arg=1",'', headers)              
	res = conn.getresponse();
	print res.status, res.reason, res.getheader("Location")
	print res.read()
	
def get_resource():
	print "**********get resource list************"
	global headers
	conn = httplib.HTTPSConnection(server, port)
	conn.request("GET", "/sslvpn/action/getResourceList?arg=1",'', headers)              
	res = conn.getresponse();
	print res.status, res.reason
	#print res.read()
	
def get_ipaccess_param():
	print "**********get ipaccess parameter************"
	global headers
	conn = httplib.HTTPSConnection(server, port)
	conn.request("GET", "/sslvpn/action/getIPAccessParam?arg=1",'', headers)              
	res = conn.getresponse();
	print res.status, res.reason
	
	param = res.read()
	#print "before base64:", param
	d_param = base64.decodestring(param)
	#print base64.encodestring(d_param)
	#print d_param
	length = len(d_param)
	#print "length %d" % (length) 
	
	# write all ip parameter
	ip = open('ip_parameter', 'wb')
	ip.write(d_param)
	#write sec cookie only, last 16 bytes is iptunnel secure cookie
	sc = open('sec_cookie', 'wb')
	sc.write(d_param[length-16:])	

if __name__ == "__main__":
	headers['Cookie'] = "rjsslvpnSID="+sessionid
	#get server ip address
	serverinfo = socket.getaddrinfo(server, None);
	ipaddr = serverinfo[0][4][0];
	
	#test1();
	#test2();
	#'''
	login();
	if (do_hardid):
		check_hardid();
	get_resource();
	get_ipaccess_param();
	iptunnel_cmd = "./iptunnel.elf  -i %s -p %d -s %s -d info" % (ipaddr, port, sessionid)
	print "start iptunnel cmd: " + iptunnel_cmd
	os.system(iptunnel_cmd);
	while 1:
	    keepalive();
	    time.sleep(30);
	#'''
