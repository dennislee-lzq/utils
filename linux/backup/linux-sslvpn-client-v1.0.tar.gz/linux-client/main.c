/*
 * IPTunnelJni.c
 *
 *  Created on: 2014-9-11
 *      Author: "wuyongjin@ruijie.com.cn"
 *
 *  ���ܣ������Jni Java�ĶԽӼ�IP����Native���п��
 *
 *  ע�ͣ�
 *    1. ���еĿ�����Ϣ����Java�����н��н������ַ���Ч��
 *    2. VPN�ӿ���Java�����д�������ɵ�FDͨ��Jni����ͬ����Native�����У�����������Select�����������
 *    3. �����¼��շ����������׽�����Java�д�����Connect��ͨ��Jni���󴫵ݵ�Native�У�
 *       eventServerʹ��Select��Acceptһ���������׽��֣����ø���������Client�����¼��շ���
 */

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <stdbool.h>
#include <linux/string.h>
#include <sys/socket.h>
#include <errno.h>
#include <asm/ioctls.h>
#include <linux/in.h>
#include <linux/un.h>
#include <sys/select.h>
#include <endian.h>

#include <sys/types.h>
#include "iptunnel.h"
#include "debug.h"
#include "timer.h"
#include "ssl_iptunnel.h"

static int iptun_vpn_pkt_dispatch(uint8_t *vpn_pkt, int pkt_len, uint8_t *exit, int *max_skt);

/* ȫ��debug���ر��� */
uint8_t g_info_debug_sw = true;
uint8_t g_warn_debug_sw = true;
uint8_t g_error_debug_sw = true;
uint8_t g_ssl_debug_sw = true;
uint8_t g_bio_debug_sw = true;

/* ȫ�ֵ�������������� */
iptun_running_ctx_t g_running_ctx;

/* 
 * parse config and init ctx, include:
 *  #. debug level
 *  #. ip access para
 *  # iptunnel.elf  -i ip -p port -s sid [-d info | warn | error | ssl | bio]
 */
static int iptun_parse_config(int argc,  char *argv[])
{
	 int result;
	 FILE *sc;

	while ((result=getopt(argc, argv, "i:p:s:d:")) != -1) {
		switch(result) {
		case 'i':
			printf("get ip addr %s\n",  optarg);
			if (optarg != NULL) {
				strncpy(g_running_ctx.server_ipstr, optarg, SSLVPN_IP_ADDR_LEN);
			}
			break;
		case 'p':
			printf("get port %s\n",  optarg);
			 g_running_ctx.server_port = (uint16_t)atoi(optarg);
			break;
		case 's':
			printf("get session id %s\n",  optarg);
			memcpy(g_running_ctx.sid, optarg, sizeof(g_running_ctx.sid));
			break;
		case 'd':
			printf("get debug flag %s\n", optarg);
			if (strcmp(optarg, "info") == 0) {
				g_info_debug_sw = 1;
			} else if (strcmp(optarg, "warn") == 0) {
				g_warn_debug_sw = 1;
			} else  if (strcmp(optarg, "error") == 0) {
				g_error_debug_sw = 1;
			} if (strcmp(optarg, "ssl") == 0) {
				g_ssl_debug_sw = 1;
			} else if (strcmp(optarg, "bio") == 0) {
				g_bio_debug_sw = 1;
			}
			break;
		default:
			printf("Unknown arg %c  %s for %s\n",result, optarg, argv[0]);
			break;
		}
	}

	sc = fopen("sec_cookie", "rb");
	if (sc == NULL) {
		printf("open sec cookie file fail\n");
		exit(-1);
	}
	if (fread(g_running_ctx.cookie_seed,  sizeof(g_running_ctx.cookie_seed), 1, sc) == -1 ) {
			printf("read sec cookie fail\n");
			exit(-1);
	}

    if (g_running_ctx.server_ipstr[0] == 0) {
    	printf("Invalid server ipaddr\n");
    	printf("Usage: iptunnel.elf  -i ip -p port -s sid [-d info | warn | error | ssl | bio] \n ");
    	 exit(-1);
    }
    if (g_running_ctx.server_port == 0) {
    	printf("Invalid server port\n");
    	 printf("Usage: iptunnel.elf  -i ip -p port -s sid [-d info | warn | error | ssl | bio] \n ");
    	 exit(-1);
    }
    if ( g_running_ctx.sid[0] == 0) {
    	printf("Invalid server session id\n");
    	printf("Usage: iptunnel.elf  -i ip -p port -s sid [-d info | warn | error | ssl | bio] \n ");
    	exit(-1);
    }
    if (g_running_ctx.cookie_seed[0] == 0 ) {
    		printf("Invalid cookie seed, check file sec_cookie\n ");
    		exit(-1);
    }
    printf("Parse config ok\n");

    return SSLVPN_IPTUN_OK;
}

/* �����׽���Ϊ������ */
static inline int iptun_set_nonblock(int socket)
{
    int sock_opt;
    int set_ret;

    sock_opt = 1;
    set_ret = ioctl(socket, FIONBIO, &sock_opt);
    if (set_ret < 0) {
        return SSLVPN_IPTUN_ERROR;
    }

    return SSLVPN_IPTUN_OK;
}

static inline void iptun_set_fd_buf_size(int fd,  int recv_size, int send_size)
{
    int fd_buf_size;

    fd_buf_size = recv_size;
    if (setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &fd_buf_size, sizeof(fd_buf_size)) < 0) {
        print_error("The recv buf size of %d set to %d failed: %d!\n", fd, recv_size, errno);
    }
    fd_buf_size = send_size;
    if (setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &fd_buf_size, sizeof(fd_buf_size)) < 0) {
        print_error("The snd buf size of %d set to %d failed: %d!\n", fd, send_size, errno);
    }

    return;
}

/* ������������socket, �ɹ������׽��֡�ʧ�ܷ���SSLVPN_IPTUN_ERROR */
static int udpSocketCreate(void)
{
    int wan_fd;

    wan_fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (wan_fd < 0) {
        print_error("wan fd create failed, err: %d!\n", errno);
        return SSLVPN_IPTUN_ERROR;
    }

    /* ����Ϊ������ */
    if (iptun_set_nonblock(wan_fd) == SSLVPN_IPTUN_ERROR) {
        print_error("wan fd nonblock failed, err: %d!\n", errno);
        close(wan_fd);
        return SSLVPN_IPTUN_ERROR;
    }

    iptun_set_fd_buf_size(wan_fd, SSLVPN_WAN_FD_BUF_SIZE, SSLVPN_WAN_FD_BUF_SIZE);

    return wan_fd;
}

void iptun_ssl_cookie_update(unsigned char *cookie, unsigned int len)
{
    unsigned char   md[EVP_MAX_MD_SIZE];
    unsigned int    md_len;

    /* Calculate HMAC of buffer using the secret */
    md_len = sizeof(md);
    HMAC(EVP_sha1(), g_running_ctx.cookie_seed, COOKIE_SEED_LENGTH, cookie, len, md, &md_len);

    /* ���бȽϣ���ֹ��дssl��������� */
    if (len == md_len) {
        memcpy(cookie, md, md_len);
    } else {
        print_error("sslvpn iptunnel dtls handshake get bad cookie[%d vs %d]\n", len, md_len);
    }

    return;
}

/* SSL���ֳɹ��Ļص����� */
void iptun_ssl_handshake_ok()
{
    int ret;

    g_running_ctx.state = IPTUN_STATE_SSL_OK;

    iptun_timer_close(&g_running_ctx.timer_ctx, &g_running_ctx.handshake_resend);
    iptun_timer_close(&g_running_ctx.timer_ctx, &g_running_ctx.handshake_limit);

    ret = iptun_ctrl_reliable_send(&g_running_ctx.ctrl_ctx, g_running_ctx.ssl, &g_running_ctx.timer_ctx,
            IPTUN_CTRL_TYPE_SID_CHECK, SSLVPN_SESSIONID_LEN, g_running_ctx.sid);
    if (ret == SSLVPN_IPTUN_ERROR) {
        print_error("reliable send fail, pls try again\n");
        return;
    }

    ret = iptun_ctrl_reliable_send(&g_running_ctx.ctrl_ctx, g_running_ctx.ssl, &g_running_ctx.timer_ctx,
            IPTUN_CTRL_TYPE_CFG_REQ, 0, NULL);
    if (ret == SSLVPN_IPTUN_ERROR) {
        print_error("reliable send fail, pls try again\n");
        return;
    }
    g_running_ctx.state = IPTUN_STATE_CFG_REQ;

    (void)iptun_timer_open(&g_running_ctx.timer_ctx, &g_running_ctx.holdtime, g_running_ctx.holdtime_sec);
    (void)iptun_timer_open(&g_running_ctx.timer_ctx, &g_running_ctx.traffic_echo, IPTUN_TIMER_TYPE_TRAFFIC_ITV);

    return;
}

static int iptun_ssl_resend(int *max_skt)
{
    uint8_t recv_buf[IPTUN_BUFSIZE];
    int     recv_ret;
    uint8_t exit;

    iptun_timer_reset(&g_running_ctx.timer_ctx, &g_running_ctx.handshake_resend, 1);
    recv_ret = iptun_ssl_read(g_running_ctx.ssl, recv_buf, (int)IPTUN_BUFSIZE);
    if (recv_ret == SSLVPN_IPTUN_ERROR) {
        print_error("iptun select error, Err: %s!\n", strerror(errno));
        return SSLVPN_IPTUN_FATAL;
    }
    if (recv_ret > 0 ) {
        return iptun_vpn_pkt_dispatch(recv_buf, recv_ret, &exit, max_skt);
    }

    return SSLVPN_IPTUN_OK;
}

static int initRunningCtx()
{
    struct sockaddr_in peer;
    struct in_addr serverIp;

    g_running_ctx.wan_udp_skt = udpSocketCreate();
    if (g_running_ctx.wan_udp_skt == SSLVPN_IPTUN_ERROR) {
        return SSLVPN_IPTUN_ERROR;
    }

    if (iptun_timer_ctx_init(&g_running_ctx.timer_ctx) == SSLVPN_IPTUN_ERROR) {
        goto closeWanSkt;
    }

    g_running_ctx.ssl_ctx = iptun_ssl_ctx_init();
    if (g_running_ctx.ssl_ctx == NULL) {
        goto timerCtxFree;
    }

    inet_aton(g_running_ctx.server_ipstr, &serverIp);
    peer.sin_addr = serverIp;
    peer.sin_port = htons(g_running_ctx.server_port);
    peer.sin_family = AF_INET;
    if (connect(g_running_ctx.wan_udp_skt, (struct sockaddr *)&peer, sizeof(peer)) == -1) {
        /* UDP connectֻ�ǻ�ȷ�ϱ����׽��֣�������ʵ����Զ˷������ */
        goto sslCtxFree;
    }

    g_running_ctx.ssl = iptun_ssl_new(g_running_ctx.ssl_ctx, g_running_ctx.wan_udp_skt,
                            (struct sockaddr*)&peer, iptun_ssl_callback);
    if (g_running_ctx.ssl == NULL) {
        goto sslCtxFree;
    }
    iptun_timer_init(&g_running_ctx.handshake_resend,   IPTUN_TIMER_TYPE_RESEND);
    iptun_timer_init(&g_running_ctx.handshake_limit,    IPTUN_TIMER_TYPE_HANDSHAKE);

    g_running_ctx.holdtime_sec = 60;
    iptun_timer_init(&g_running_ctx.holdtime, IPTUN_TIMER_TYPE_ALIVE);
    g_running_ctx.recv_msg_total_last = 0;

    iptun_ctrl_ctx_init(&g_running_ctx.ctrl_ctx);
    g_running_ctx.vpn_intf_fd = -1;

    iptun_timer_init(&g_running_ctx.traffic_echo, IPTUN_TIMER_TYPE_TRAFFIC_ECHO);

    g_running_ctx.state = IPTUN_STATE_INIT;

    return SSLVPN_IPTUN_OK;

/* ͨ��goto�ķ�ʽ������Դ�ͷ� */
sslFree:
    iptun_ssl_free(&g_running_ctx.ssl);
sslCtxFree:
    iptun_ssl_ctx_free(&g_running_ctx.ssl_ctx);
timerCtxFree:
    iptun_timer_ctx_free(&g_running_ctx.timer_ctx);
closeWanSkt:
    close(g_running_ctx.wan_udp_skt);
    return SSLVPN_IPTUN_ERROR;
}

static void freeRunningCtx()
{
    if (g_running_ctx.vpn_intf_fd != -1) {
         close(g_running_ctx.vpn_intf_fd);
     }
    iptun_ctrl_ctx_free(&g_running_ctx.ctrl_ctx, &g_running_ctx.timer_ctx);
    iptun_ssl_free(&g_running_ctx.ssl);
    iptun_ssl_ctx_free(&g_running_ctx.ssl_ctx);
    iptun_timer_ctx_free(&g_running_ctx.timer_ctx);
    close(g_running_ctx.wan_udp_skt);
    g_running_ctx.state = IPTUN_STATE_DESTORY;
}

/* ȡ���������ȡ���ֵ */
static inline int iptun_max_4int(int a, int b, int c, int d)
{
    if (a < b) {
        a = b;
    }
    if (a < c) {
        a = c;
    }
    if (a < d) {
        a = d;
    }

    return a;
}

void iptun_send_exit(uint8_t exit_code)
{
    uint8_t exit_msg[IPTUN_VPN_HDR_BYTES + 1]; /* ��Զ˷��͵��˳���������ֻ��һ���ֽ� */

    exit_msg[0] = VPN_MSG_TYPE_EXIT;
    exit_msg[IPTUN_VPN_HDR_BYTES] = exit_code;

    iptun_ssl_write(g_running_ctx.ssl, exit_msg, sizeof(exit_msg));

    print_info("Try to exit, exit code: %d", exit_code);
    return;
}

/* ����ӷ������յ��ı���ping���� */
static int iptun_procs_ping(uint8_t *ping_msg, uint16_t ping_len)
{
    uint16_t holdtime;

    if (ping_msg == NULL || ping_len == 0) {
        print_error("Bad ping info: msg%p, len: %d.\n", ping_msg, ping_len);
        return SSLVPN_IPTUN_ERROR;
    }

    memcpy(&holdtime, ping_msg, sizeof(uint16_t));
    holdtime = ntohs(holdtime);
    if (holdtime <= 0) {
        print_error("Resolve heartbeat message fails.\n");
    }
    g_running_ctx.holdtime_sec = holdtime;
    g_running_ctx.recv_msg_total_last = g_running_ctx.recv_msg_total;

    /* ���ñ��ʱ�� */
    iptun_timer_reset(&g_running_ctx.timer_ctx, &g_running_ctx.holdtime, g_running_ctx.holdtime_sec);

    return SSLVPN_IPTUN_OK;
}

/* ����ӷ������յ��ı���ping���� */
static int iptun_procs_keepalvie_timeout()
{
    /* α��ʱ�ж� */
    if (g_running_ctx.recv_msg_total != g_running_ctx.recv_msg_total_last) {
        /* α��ʱ��ֻ�����ö�ʱ�� */
        g_running_ctx.recv_msg_total_last = g_running_ctx.recv_msg_total;
        iptun_timer_reset(&g_running_ctx.timer_ctx, &g_running_ctx.holdtime, g_running_ctx.holdtime_sec / 2);
        return SSLVPN_IPTUN_OK;
    }

    iptun_timer_close(&g_running_ctx.timer_ctx, &g_running_ctx.holdtime);
    iptun_send_exit(IPTUN_EXIT_CODE_PINT_OUT);
    return SSLVPN_IPTUN_FATAL;
}

static int iptun_procs_ctrl_msg(uint8_t *ctrl_msg, int msg_len, int *max_skt)
{
    int         call_ret;

    call_ret = iptunConfigParse(ctrl_msg, msg_len);
    if (call_ret == SSLVPN_IPTUN_ERROR) {
        /* Java�������õ�ʱ�������ش��� */
        print_error("Configuation parse callback failed!");
        iptun_send_exit(IPTUN_EXIT_CODE_CLI_ERR);
        return SSLVPN_IPTUN_FATAL;
    }

    if (call_ret == 1) {
        if (g_running_ctx.vpn_intf_fd >= *max_skt) {
            *max_skt = g_running_ctx.vpn_intf_fd + 1;
        }
        g_running_ctx.state = IPTUN_STATE_FORWORD;
    }

    return SSLVPN_IPTUN_OK;
}

/* �Խ��װ������VPN���Ľ��зַ����� */
static int iptun_vpn_pkt_dispatch(uint8_t *vpn_pkt, int pkt_len, uint8_t *exit, int *max_skt)
{
    uint8_t vpn_type, *vpn_msg;
    int ret;
    int vpn_msg_len;
    uint8_t *ctrl_msg;
    uint16_t ctrl_msg_len;

    vpn_type = vpn_pkt[0];
    vpn_msg = vpn_pkt + IPTUN_VPN_HDR_BYTES;
    vpn_msg_len = pkt_len - IPTUN_VPN_HDR_BYTES;

    switch (vpn_type) {
    case VPN_MSG_TYPE_DATA:
        ret = write(g_running_ctx.vpn_intf_fd, vpn_msg, vpn_msg_len, 0);
        g_running_ctx.recv_msg_total++;
        g_running_ctx.recv_byte_total += vpn_msg_len;
        if (ret <= 0) {
            print_error("ip pkt write to intf ret is %d err is %d\n", ret, errno);
            g_running_ctx.recv_msg_drop++;
        }
        break;
    case VPN_MSG_TYPE_CTRL:
        *exit = 0;
        /* �Կ��Ʊ��Ľ��н��������� */
        ret =  iptun_procs_ctrl_pkt(&g_running_ctx.ctrl_ctx, g_running_ctx.ssl, &g_running_ctx.timer_ctx,
                vpn_msg, vpn_msg_len, &ctrl_msg, &ctrl_msg_len);
        if (ret != SSLVPN_IPTUN_OK) {
            return ret;
        }
        if (ctrl_msg_len > 0) {
            ret = iptun_procs_ctrl_msg(ctrl_msg, ctrl_msg_len, max_skt);
            if (ret == SSLVPN_IPTUN_FATAL) {
                *exit = 1;
            }
            return ret;
        }
        break;
    case VPN_MSG_TYPE_PING:
        (void)iptun_procs_ping(vpn_msg, vpn_msg_len);
        break;
    case VPN_MSG_TYPE_EXIT:
        /* �յ��˳�ͨ�棬������������� */
        *exit = 1;
        return SSLVPN_IPTUN_FATAL;
    default:
        break;
    } /* switch��������ܷ���SSLVPN_IPTUN_FATAL�ķ�֧����*exit���и�ֵ��������� */

    return SSLVPN_IPTUN_OK;
}

static int iptun_timer_dispatch(iptun_timer_t *timer, int *max_skt)
{
    int type;

    type = timer->type;
    print_info("Timer %d timeout now!", type);
    switch (type){
    case IPTUN_TIMER_TYPE_HANDSHAKE:
        print_ssl("SSL Handshake timeout!");
        return SSLVPN_IPTUN_FATAL;

    case IPTUN_TIMER_TYPE_RESEND:
        return iptun_ssl_resend(max_skt);

    case IPTUN_TIMER_TYPE_ALIVE:
        return iptun_procs_keepalvie_timeout();

    case IPTUN_TIMER_TYPE_CTRL:
        return iptun_ctrl_resend(&g_running_ctx.ctrl_ctx, g_running_ctx.ssl, &g_running_ctx.timer_ctx);

    case IPTUN_TIMER_TYPE_TRAFFIC_ECHO:
        iptun_timer_reset(&g_running_ctx.timer_ctx, &g_running_ctx.traffic_echo, IPTUN_TIMER_TYPE_TRAFFIC_ITV);
        break;

    default:
        break;
    }

    return SSLVPN_IPTUN_OK;
}

/* Usage: iptunnel -f /etc/iptunnel.conf */
int main(int argc, char *argv[])
{
    int ret, errcode;
    fd_set  rset;
    int     max_skt;
    struct timeval  timeout;
    uint8_t recv_buf[IPTUN_BUFSIZE];
    int     recv_ret;
    iptun_timer_t *timeout_timer;
    uint8_t  exit;

    memset(&g_running_ctx, 0, sizeof(iptun_running_ctx_t));
    iptun_cfg_init();
    
    g_error_debug_sw = 1;
    g_running_ctx.state = IPTUN_STATE_UNSET;

    /* XXX: parse config file  */
	if (iptun_parse_config(argc, argv) == SSLVPN_IPTUN_ERROR) {
		printf("parse config fail\n");
	    return SSLVPN_IPTUN_ERROR;
	}

	OpenSSL_add_ssl_algorithms();
    SSL_load_error_strings();

    /* ������Ϣ���ڴ˴����ó�0���������������������Ϣ��� */
    g_running_ctx.recv_byte_total   = 0;
    g_running_ctx.send_byte_total   = 0;
    g_running_ctx.recv_msg_total    = 0;
    g_running_ctx.recv_msg_drop     = 0;
    g_running_ctx.send_msg_total    = 0;
    g_running_ctx.discard_ip_illegal = 0;

dtlsConnectAgain:
    if (initRunningCtx() == SSLVPN_IPTUN_ERROR) {
    	printf("initRunningCtx fail\n");
	    return SSLVPN_IPTUN_ERROR;
    }

    ret = SSL_do_handshake(g_running_ctx.ssl);
    if (ret < 0) {
        errcode = SSL_get_error(g_running_ctx.ssl, ret);
        if (errcode != SSL_ERROR_WANT_READ) {
            /* ���������֣�һ���᷵��С��0�������want_read��ʾ�� */
            print_error("SSL handshake fails. errcode is %d\n", errcode);
            goto freeCtx;
        }
    }
    iptun_timer_open(&g_running_ctx.timer_ctx, &g_running_ctx.handshake_limit, 15);
    iptun_timer_open(&g_running_ctx.timer_ctx, &g_running_ctx.handshake_resend, 1);

    max_skt = iptun_max_4int(g_running_ctx.event_server_fd, g_running_ctx.wan_udp_skt,
                g_running_ctx.event_client_connect_fd, g_running_ctx.vpn_intf_fd) + 1;
    while (1) {
        FD_ZERO(&rset);
        FD_SET(g_running_ctx.wan_udp_skt, &rset);
        if (g_running_ctx.vpn_intf_fd != -1) {
            FD_SET(g_running_ctx.vpn_intf_fd, &rset);
        }
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;
        ret = select(max_skt, &rset, NULL, NULL, &timeout);
        if (ret < 0) {
            print_error("iptun select error, Err: %s!\n", strerror(errno));
            continue;
        }
        
        if (FD_ISSET(g_running_ctx.wan_udp_skt, &rset)) {
            /* ����SSL���գ��������յ������ */
            recv_ret = iptun_ssl_read(g_running_ctx.ssl, recv_buf, (int)IPTUN_BUFSIZE);
            if (recv_ret == SSLVPN_IPTUN_ERROR) {
                print_error("iptun select error, Err: %s!\n", strerror(errno));
                goto dtlsReconFree;
            }
            if (recv_ret > 0 ) {
                ret = iptun_vpn_pkt_dispatch(recv_buf, recv_ret, &exit, &max_skt);
                if (ret == SSLVPN_IPTUN_FATAL) {
                    if (exit == 1) {
                        goto freeCtx;
                    }
                    goto dtlsReconFree;
                }
            }
        }

        if (g_running_ctx.vpn_intf_fd != -1 && FD_ISSET(g_running_ctx.vpn_intf_fd, &rset)) {
            /* ��VPN�ӿڶ�ȡIP���ģ������͵������� */
            ret = read(g_running_ctx.vpn_intf_fd,
                    recv_buf + IPTUN_VPN_HDR_BYTES, IPTUN_BUFSIZE - IPTUN_VPN_HDR_BYTES, 0);
            if (ret > 0) {
                recv_buf[0] = VPN_MSG_TYPE_DATA;
                ret = iptun_ssl_write(g_running_ctx.ssl, recv_buf, ret + IPTUN_VPN_HDR_BYTES);
                if (ret == SSLVPN_IPTUN_ERROR) {
                    goto dtlsReconFree;
                }
                g_running_ctx.send_msg_total++;
                g_running_ctx.send_byte_total += (ret - IPTUN_VPN_HDR_BYTES);
            }
        }

        /* ��ȡ��ʱ��ʱ�������� */
        while (1) {
            timeout_timer = iptun_timer_get(&g_running_ctx.timer_ctx);
            if (timeout_timer == NULL) {
                break;
            }
            ret = iptun_timer_dispatch(timeout_timer, &max_skt);
            if (ret == SSLVPN_IPTUN_FATAL) {
                goto dtlsReconFree;
            }
        }
    }

dtlsReconFree:
    g_running_ctx.state = IPTUN_STATE_RECONN_NOW;
    sleep(30);   // �ȴ�30���ٽ���������������������Ƶ��
    freeRunningCtx();
    goto dtlsConnectAgain;

freeCtx:
    freeRunningCtx();
    return SSLVPN_IPTUN_ERROR;
}

