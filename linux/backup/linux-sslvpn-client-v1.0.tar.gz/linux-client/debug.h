/*
 * iptunnel_log.h
 *
 *  Created on: 2014-9-9
 *      Author: wuyongjin@ruijie.com.cn
 */

#ifndef _IPTUNNEL_DEBUG_H_
#define _IPTUNNEL_DEBUG_H_


extern uint8_t g_info_debug_sw;
extern uint8_t g_warn_debug_sw;
extern uint8_t g_error_debug_sw;
extern uint8_t g_ssl_debug_sw;
extern uint8_t g_bio_debug_sw;

#define TAG "SSLVPN Iptun native"
#define DEBUG_ANDROID_PRINT(fmt, ...) printf(fmt "\n" , ## __VA_ARGS__)

#define print_info(fmt, arg...) do { \
    if (g_info_debug_sw) { \
	    (void)DEBUG_ANDROID_PRINT("[%s:%d]" fmt, __FUNCTION__, __LINE__, ##arg); \
    } \
} while(0)

#define print_warn(fmt, arg...) do { \
    if (g_warn_debug_sw) { \
        (void)DEBUG_ANDROID_PRINT("[%s:%d]" fmt, __FUNCTION__, __LINE__, ##arg); \
    } \
} while(0)

#define print_error(fmt, arg...) do { \
    if (1 || g_error_debug_sw) { \
	    (void)DEBUG_ANDROID_PRINT("[%s:%d]" fmt, __FUNCTION__, __LINE__, ##arg); \
    } \
} while(0)

#define print_ssl(fmt, arg...) do { \
    if (g_ssl_debug_sw) { \
        (void)DEBUG_ANDROID_PRINT("[%s:%d]" fmt, __FUNCTION__, __LINE__, ##arg); \
    } \
} while(0)

#define print_bio(fmt, arg...) do { \
    if (g_bio_debug_sw) { \
        (void)DEBUG_ANDROID_PRINT("[%s:%d]" fmt, __FUNCTION__, __LINE__, ##arg); \
    } \
} while(0)

#define iptun_print(fmt, arg...) do { \
	(void)DEBUG_ANDROID_PRINT("[%s:%d]" fmt, __FUNCTION__, __LINE__, ##arg); \
} while(0)

static void iptun_dump_msg(uint8_t *buf, int len)
{
    char print_buf[3 * 17];             /* ��ʮ�����ƴ�ӡ�����ġ��ÿո���� */
    int buffed;                         /* ��ʾ�Ѿ���bufд����ַ����� */
    int i;

    /* ��ʮ�����ƴ�ӡ�����еĿ�����Ϣ���� */
    buffed = 0;
    for (i = 0; i < len; i++) {
        if ((i & 0X0F) == 0X0F) {
            /* ÿ�д�ӡ16���ֽڣ�ȡ���4λ�������15���ӡһ�س� */
            sprintf(print_buf + buffed, "%02X\n", (uint8_t)buf[i]);
            buffed = 0;
            DEBUG_ANDROID_PRINT("%s", print_buf);
            print_buf[0] = 0;
        } else {
            buffed += sprintf(print_buf + buffed, "%02X ", (uint8_t)buf[i]);
        }
    }
    DEBUG_ANDROID_PRINT("%s", print_buf);   /* ��ʾ��δ��һ�е���Ϣ */

    return;
}

#endif /* _IPTUNNEL_DEBUG_H_ */
